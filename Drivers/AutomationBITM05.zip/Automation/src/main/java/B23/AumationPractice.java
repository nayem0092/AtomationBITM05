package B23;

import org.openqa.selenium.WebDriver;

public class AumationPractice {
    public static WebDriver driver;

    public static void main(String[] args) {
        chrome_launch();
        browder_maximun_size();


    }
}
